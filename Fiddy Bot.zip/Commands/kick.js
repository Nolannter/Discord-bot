const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'kick',
    description: 'Kick a user',
    run: async (client, message, args) => {

        if (!message.member.permissions.has('KICK_MEMBERS')) {
            return message.channel.send('Du bist zu unbedeutend, um jemanden zu kicken.');
        }


        if (!message.guild.me.permissions.has('KICK_MEMBERS')) {
            return message.channel.send('Ich habe nicht die Berechtigung, Mitglieder zu kicken :middle_finger: .');
        }


        const user = message.mentions.members.first();
        if (!user) {
            return message.channel.send('Wen willst du kicken?');
        }


        if (user.id === message.author.id) {
            return message.channel.send('Du kannst dich nicht selbst kicken, bruh. :middle_finger:.');
        }

        if (user.id === client.user.id) {
            return message.channel.send('Ich kann mich nicht selbst kicken, fick dich :middle_finger:.');
        }


        const reason = args.slice(1).join(' ') || 'Kein Grund angegeben';


        try {
            await user.kick(reason);
            const embed = new MessageEmbed()
                .setTitle('Benutzer gekickt')
                .setDescription(`${user.user.tag} wurde erfolgreich gekickt.`)
                .addField('Grund', reason)
                .setColor('ORANGE');
            message.channel.send({ embeds: [embed] });
        } catch (error) {
            console.error('Fehler beim Kicken des Benutzers:', error);
            message.channel.send('Ein Fehler ist aufgetreten. Der Benutzer konnte nicht gekickt werden.');
        }
    },
};