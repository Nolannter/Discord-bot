const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'unban',
    description: 'Unban a user',
    run: async (client, message, args) => {
        if (!message.member.permissions.has('BAN_MEMBERS')) {
            return message.channel.send('Du bist zu schwach, um jemanden zu entbannen.');
        }

        if (!message.guild.me.permissions.has('BAN_MEMBERS')) {
            return message.channel.send('Ich habe nicht die Berechtigung, Mitglieder zu entbannen :middle_finger:.');
        }


        if (!args[0]) {
            return message.channel.send('Bitte gib die ID oder erwähne den Benutzer, den du entbannen möchtest.');
        }


        let userId = args[0].replace(/\D/g, ''); 
        if (!userId) {

            const user = message.mentions.users.first();
            if (user) {
                userId = user.id;
            }
        }

        if (!userId) {
            return message.channel.send('Ungültige Benutzer-ID oder Erwähnung.');
        }

        message.guild.members.unban(userId)
        .then(() => {

            client.users.fetch(userId)
                .then(bannedUser => {
                    const embed = new MessageEmbed()
                        .setTitle('Benutzer entbannt')
                        .setDescription(`<@${bannedUser.id}> (${bannedUser.tag}) wurde erfolgreich entbannt.`)
                        .setColor('GREEN');
                    message.channel.send({ embeds: [embed] });
                })
                .catch(error => {
                    console.error('Fehler beim Abrufen des Benutzers:', error);
                    message.channel.send('Ein Fehler ist aufgetreten. Der Benutzer konnte nicht entbannt werden. :middle_finger: Ist er vielleicht schon entbannt?');
                });
        })
        .catch(error => {

            if (error.message.includes('Unknown Ban')) {

                message.guild.members.fetch(userId)
                    .then(bannedUser => {
                        message.channel.send(`<@${bannedUser.user.id}> ist bereits entbannt.`);
                    })
                    .catch(err => {
                        console.error('Fehler beim Abrufen des entbannten Benutzers:', err);
                        message.channel.send('Ein Fehler ist aufgetreten. Der Benutzer konnte nicht entbannt werden. :middle_finger:');
                    });
            } else {

                console.error('Fehler beim Entbannen des Benutzers:', error);
                message.channel.send('Ein Fehler ist aufgetreten. Der Benutzer konnte nicht entbannt werden. :middle_finger:');
            }
        });

    },
};