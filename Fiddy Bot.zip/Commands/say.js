module.exports = {
    name: 'say',
    description: 'Lässt den Bot eine Nachricht senden und löscht die ursprüngliche Nachricht des Autors.',
    run: async (client, message, args) => {

        if (!args.length) {
            return message.channel.send('Digga, was soll ich sagen? :middle_finger:.');
        }


        message.channel.send(args.join(' '))
            .then(() => {

                message.delete()
                    .catch(error => console.error('Ich habe keine Rechte :middle_finger::', error));
            })
            .catch(error => console.error('Fehler beim Senden der Nachricht:', error));
    },
};