const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'luck',
    description: 'Würfelt einen oder mehrere Würfel oder spielt Kopf oder Zahl.',
    usage: 'luck [Würfelzahl]',
    run: async (client, message, args) => {
        if (!args.length) {
            return message.channel.send('Was willst du. Entweder -luck "Würfel" oder -luck "Kopfzahl".');
        }

        const subCommand = args[0].toLowerCase();

        if (subCommand === 'würfel') {
            let diceCount = 1;
            if (args.length > 1) {
                diceCount = parseInt(args[1]);
                if (isNaN(diceCount) || diceCount < 1 || diceCount > 6) {
                    return message.channel.send('Digga ich habe nur 6 würfel.');
                }
            }

            const results = [];
            for (let i = 0; i < diceCount; i++) {
                const result = Math.floor(Math.random() * 6) + 1;
                results.push(result);
            }

            const embed = new MessageEmbed()
                .setTitle('Würfelergebnis')
                .setDescription(`Du hast ${diceCount > 1 ? 'die Würfel' : 'einen Würfel'} geworfen.`)
                .addField('Ergebnisse', results.join(', '))
                .setColor('BLACK');

            message.channel.send({ embeds: [embed] });
        } else if (subCommand === 'kopfzahl') {
            const result = Math.random() < 0.5 ? 'Kopf' : 'Zahl';

            const embed = new MessageEmbed()
                .setTitle('Kopf oder Zahl')
                .setDescription(`Du hast Kopf oder Zahl gewählt.\nDas Ergebnis ist ${result}.`)
                .setColor('BLACK');

            message.channel.send({ embeds: [embed] });
        } else {
            return message.channel.send('Was willst du. Entweder -luck "Würfel" oder -luck "Kopfzahl".');
        }
    },
};
