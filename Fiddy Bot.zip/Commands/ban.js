const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'ban',
    description: 'Ban a user',
         run: async (client, message, args) => {

        if (!message.member.permissions.has('BAN_MEMBERS')) {
            return message.channel.send('Du bist nicht stark genug, um jemanden zu bannen :middle_finger:');
        }


        if (!message.guild.me.permissions.has('BAN_MEMBERS')) {
            return message.channel.send('Ich habe nicht die Berechtigung, Mitglieder zu bannen.');
        }


        const user = message.mentions.users.first();


        if (!user) {
            return message.channel.send('Wen willst du bannen?');
        }


        const reason = args.slice(1).join(' ') || 'Kein Grund angegeben.';


        message.guild.members.ban(user, { reason })
            .then(() => {

                const embed = new MessageEmbed()
                    .setTitle('Benutzer gebannt')
                    .setDescription(`**${user.tag}** wurde gebannt :middle_finger: .\nGrund: ${reason}`)
                    .setColor('RED');
                message.channel.send({ embeds: [embed] });
            })
            .catch(error => {

                console.error('Fehler beim Bannen des Benutzers:', error);
                message.channel.send('Ein Fehler ist aufgetreten. Der Benutzer konnte nicht gebannt werden.');
            });
    },
};
