const express = require('express');
const { Client, Intents, MessageEmbed, Collection } = require('discord.js');
const app = express();

app.get("/", (req, res) => {
  res.send('<html><head><title>Web view</title></head><body style="margin: 0; padding: 0;"><h1>Fiddy</h1></body></html>');
});

app.listen(3000, () => {
  console.log("Fiddy bot läuft!");
});

const client = new Client({ 
  intents: [
    "GUILDS",
    "GUILD_MESSAGES",
    "DIRECT_MESSAGES",
    "GUILD_MESSAGE_REACTIONS",
    "GUILD_MESSAGE_TYPING",
    "GUILD_PRESENCES",
    "GUILD_MEMBERS"
  ],
  allowedMentions: { parse: ['users'] }
});

const fs = require('fs');
const prefix = "-";
client.commands = new Collection();
const commandFiles = fs.readdirSync("./Commands").filter(file => file.endsWith(".js"));
for (const file of commandFiles) {
  const commandName = file.split(".")[0];
  const command = require(`./Commands/${commandName}`);
  client.commands.set(commandName, command);
}

client.on("messageCreate", message => {
  console.log("Nachricht empfangen!", message.content);

  if(message.content.startsWith(prefix)) {
    const args = message.content.slice(prefix.length).trim().split(/ +/g);
    const commandName = args.shift();
    const command = client.commands.get(commandName);
    if(!command) return;
    command.run(client, message, args);
  }

  if (message.content === "Fiddy") {
    console.log("Fiddy-Bedingung erreicht");
    message.channel.send("Fiddy selbst :middle_finger:");
  }
  if (message.content.includes("!help")) {
    console.log("!help-Bedingung erreicht");
    message.channel.send("nö :middle_finger:");
  }
  if (message.content.startsWith("?Fiddy")) {
    console.log("?Fiddy-Bedingung erreicht");
    let embed = new MessageEmbed()
      .setTitle("Was bedeutet Fiddy")
      .setDescription("Der Twitch-Emote 'Fiddy' stellt einen Mittelfinger dar und wird oft humorvoll oder sarkastisch verwendet. Es gibt auch einen ähnlichen Emote namens 'TwoFiddy'. Es ist wichtig zu beachten, dass es viele individuelle Interpretationen und Variationen dieses Emotes gibt, die von den verschiedenen Twitch-Streamern und ihren Communities geschaffen wurden. Daher kann die Bedeutung je nach Kontext variieren.")
      .setFooter("Fiddy")
      .setColor("DARK_GOLD");

    message.channel.send({ embeds: [embed] });
  }
});

client.login(process.env.token);
